"""Models package for CreatureStudio backend."""
