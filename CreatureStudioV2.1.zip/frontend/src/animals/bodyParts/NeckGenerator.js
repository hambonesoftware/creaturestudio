export { generateNeckGeometry } from "../../anatomy/NeckGenerator.js";
