export { generateTorsoGeometry } from "../../anatomy/TorsoGenerator.js";
