export { generateEarGeometry } from "../../anatomy/EarGenerator.js";
