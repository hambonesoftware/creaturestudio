export { generateHeadGeometry } from "../../anatomy/HeadGenerator.js";
