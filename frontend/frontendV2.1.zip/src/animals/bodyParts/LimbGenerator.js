export { generateLimbGeometry } from "../../anatomy/LimbGenerator.js";
