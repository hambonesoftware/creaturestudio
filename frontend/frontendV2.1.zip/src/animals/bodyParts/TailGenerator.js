export { generateTailGeometry } from "../../anatomy/TailGenerator.js";
