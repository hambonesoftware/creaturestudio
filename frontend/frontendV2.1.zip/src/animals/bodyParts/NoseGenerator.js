export { generateNoseGeometry } from "../../anatomy/NoseGenerator.js";
